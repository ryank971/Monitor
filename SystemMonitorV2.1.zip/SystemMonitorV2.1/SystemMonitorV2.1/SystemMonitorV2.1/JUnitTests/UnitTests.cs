﻿using System;
using CrossCutting;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using ServiceManagers;

namespace JUnitTests
{
    [TestFixture]
    public class UnitTests
    {
        [Test]
        public void TestProcessDumps_ValidDumpFile_ExpectCallToCrashLoggerLogError()
        {
            //Arrange
            FakeFileExtensionManager theFakeFileExtensionMgr = new FakeFileExtensionManager();
            FakeCrashLoggingService theFakeCrashLogger = new FakeCrashLoggingService();
            FakeEmailServices theFakeEmailServices = new FakeEmailServices();
            FakeCorruptFileLoggingService theFakeCorruptFileLoggingService = new FakeCorruptFileLoggingService();

            testableSystemMonitor theSysMon = new testableSystemMonitor(theFakeFileExtensionMgr, theFakeCrashLogger, theFakeEmailServices, theFakeCorruptFileLoggingService);
            String expectedResult = "Dump file is valid ";
            //Act
            theSysMon.ProcessDumps();
            //Assert
            Assert.AreEqual(theFakeCrashLogger.lastCalledWithMessage, expectedResult);
            // assert against the FakeCrashLogger to check it was called properly.
        }


        [Test]
        public void TestProcessDumps_InValidDumpFile_ExpectCallToCrashLoggerLogError()
        {

            //Arrange
            FakeFileExtensionManagerForInvalid theFakeFileExtensionMgr = new FakeFileExtensionManagerForInvalid();
            FakeCrashLoggingService theFakeCrashLogger = new FakeCrashLoggingService();
            FakeEmailServices theFakeEmailServices = new FakeEmailServices();
            FakeCorruptFileLoggingService theFakeCorruptFileLoggingService = new FakeCorruptFileLoggingService();

            testableSystemMonitor theSysMon = new testableSystemMonitor(theFakeFileExtensionMgr, theFakeCrashLogger, theFakeEmailServices, theFakeCorruptFileLoggingService);
            String expectedResult = "Dump file is corrupt: ";
            //Act
            theSysMon.ProcessDumps();
            //Assert

            Assert.AreEqual(theFakeCorruptFileLoggingService.Message, expectedResult);
            // assert against the FakeCrashLogger to check it was called properly.
        }


        [Test]
        public void TestProcessDumps_InValidEXDumpFile_ExpectCallToCrashLoggerLogError()
        {

            //Arrange
            FakeFileExtensionManagerForInvalid theFakeFileExtensionMgr = new FakeFileExtensionManagerForInvalid();
            FakeCrashLoggingService theFakeCrashLogger = new FakeCrashLoggingService();
            FakeEmailServices theFakeEmailServices = new FakeEmailServices();
            FakeCorruptFileLoggingService theFakeCorruptFileLoggingService = new FakeCorruptFileLoggingService();

            testableSystemMonitor theSysMon = new testableSystemMonitor(theFakeFileExtensionMgr, theFakeCrashLogger, theFakeEmailServices, theFakeCorruptFileLoggingService);
            String expectedResult = "corruptFileLoggingService Web service threw exception";
            theFakeCorruptFileLoggingService.dan = true;
            //Act
            theSysMon.ProcessDumps();
            //Assert

            Assert.AreEqual(theFakeEmailServices.Subject, expectedResult);
            // assert against the FakeCrashLogger to check it was called properly.
        }

        [Test]
        public void TestProcessDumps_ValidExDumpFile_ExpectCallToCrashLoggerLogError()
        {
            //Arrange
            FakeFileExtensionManager theFakeFileExtensionMgr = new FakeFileExtensionManager();
            FakeCrashLoggingService theFakeCrashLogger = new FakeCrashLoggingService();
            FakeEmailServices theFakeEmailServices = new FakeEmailServices();
            FakeCorruptFileLoggingService theFakeCorruptFileLoggingService = new FakeCorruptFileLoggingService();

            testableSystemMonitor theSysMon = new testableSystemMonitor(theFakeFileExtensionMgr, theFakeCrashLogger, theFakeEmailServices, theFakeCorruptFileLoggingService);
            String expectedResult = "crashLoggingService Web service threw exception";
            theFakeCrashLogger.dan = true;
            //Act
            theSysMon.ProcessDumps();
            //Assert
            Assert.AreEqual(theFakeEmailServices.Subject, expectedResult);
            // assert against the FakeCrashLogger to check it was called properly.
        }





        public class FakeFileExtensionManager : IFileExtensionManager
        {
            public string[] scanAndReadDumpfileNames()
            {
                string[] theRexsult = { "LogFile.dmp" };
                return theRexsult;
            }

            public string readAndDeleteDumpfile(string dumpFilespec)
            {
                return "something";

            }
        }

        public class FakeFileExtensionManagerForInvalid : IFileExtensionManager
        {
            public string[] scanAndReadDumpfileNames()
            {
                string[] theRexsult = { "LogFile.dp" };
                return theRexsult;
            }

            public string readAndDeleteDumpfile(string dumpFilespec)
            {
                return "something";

            }
        }


        public class FakeCrashLoggingService : ICrashLoggingService
        {
            public string lastCalledWithMessage = null;
            public string lastCalledWithdumpFilespecAndStatus = null;
            // remembers how it was called
            public Boolean dan = false;
            public void LogError(string message, string dumpFilespecAndStatus)
            {
                lastCalledWithMessage = message;
                lastCalledWithdumpFilespecAndStatus = dumpFilespecAndStatus;
                if (dan == true)
                {
                    throw new Exception();
                }
            }

        }


        public class FakeEmailServices : IEmailServices
        {
            public string To = null;
            public string Subject = null;
            public string Body = null;



            public void SendEmail(string to, string subject, string body)
            {
                To = to;
                Subject = subject;
                Body = body;

            }
        }

        public class FakeCorruptFileLoggingService : ICorruptFileLoggingService
        {
            public string Message = null;
            public string DumpFilespecAndStatus = null;
            public Boolean dan = false;
            public void LogCorruptionDetails(string message, string dumpFilespecAndStatus)
            {
                Message = message;
                DumpFilespecAndStatus = dumpFilespecAndStatus;
                if (dan == true)
                {
                    throw new Exception();
                }
            }
        }

        public class testableSystemMonitor : SystemMonitor
        {  //run tests against the subclass overriding the dependency
            public testableSystemMonitor(IFileExtensionManager theFileManager, ICrashLoggingService theCrashLogger,IEmailServices theEmailServices,ICorruptFileLoggingService theCurruptFileLoggingService)
        : base(theFileManager, theCrashLogger, theEmailServices, theCurruptFileLoggingService)
            {

            }
            protected override void createDumpFolderIfNecessary()
            {
                // just do nothing, that's all the test needs 
            }
        }
    }
}
